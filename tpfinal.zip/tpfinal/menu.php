<!-- Menú de Navegación -->

<nav class="navbar navbar-expand-lg" style="background-color: #cfd6d3">
    <div class="container-fluid">
        <a class="navbar-brand " href="index.php">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active text-secondary" aria-current="page" href="insumos.php">Insumos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-secondary" aria-current="page" href="proveedores.php">Proveedores</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-secondary" aria-current="page" href="clientes.php">Clientes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-secondary" aria-current="page" href="pedidos.php">Pedidos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-secondary" aria-current="page" href="configuracion.php">Configuración</a>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" name="buscar" value="" type="search" aria-label="Search">
                <button class="btn btn-outline-secondary" type="submit">Buscar</button>
            </form>
        </div>
    </div>
</nav>

<!-- Fin del Menú de Navegación -->
