<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artística Plumeria</title>
    <link rel="icon" href="images/logo.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="css/style.css?v=1.1" rel="stylesheet">
</head>

<body>
    <div class="container-lg">

        <!-- Menú de Navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h2>Configuración del Sistema</h2>
    
        <!-- Formulario de Configuración -->
        <form class="bg-secondary-subtle text-start p-2">


            <!-- Institución Educativa -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Institución Educativa</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="institucion" readonly
                        value="Centro de Formación Profesional N° 8 - S.M.A.T.A">
                </div>
            </div>

            <!-- Trayecto/Módulo -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Trayecto/Módulo</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="trayecto" readonly
                        value="Trayecto Programador - Módulo: Programación Orientada a Objetos">
                </div>
            </div>

            <!-- Proyecto -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Proyecto</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="proyecto" readonly
                        value="Proyecto Final (Trabajo Práctico N° 5) - Creación de un Sistema Completo">
                </div>
            </div>
            
            <!-- Profesores -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Profesores</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="profesores" readonly
                        value="Prof. Carlos Ríos y Prof. Nicolás Vargas">
                </div>
            </div>

            <!-- Alumna -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Alumna</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="alumna" readonly
                        value="Escobar Quarin, Victoria">
                </div>
            </div>

            <!-- Fecha -->
            <div class="mb-3 row">
                <label for="fecha" class="col-sm-2 col-form-label text-secondary">Fecha</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="fecha" readonly
                        value="<?php echo date("d-m-y") ?>">
                </div>
            </div>

            <!-- Tecnologías Utilizadas -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Tecnologías Utilizadas</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="tecnologias" readonly
                        value="PHP (Backend) / CSS - Bootstrap - HTML - Javascript (Frontend) / SQL (Base de Datos)">
                </div>
            </div>

            <!-- Versión de PHP -->
            <div class="mb-3 row">
                <label for="php" class="col-sm-2 col-form-label text-secondary">Versión de PHP</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="php" readonly
                        value="<?php echo phpversion(); ?>">
                </div>
            </div>

            <!-- Base de Datos -->
            <div class="mb-3 row">
                <label for="bd" class="col-sm-2 col-form-label text-secondary">Base de Datos</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="bd"readonly
                    value="<?php
                                include_once "php/connectors/connector.php";
                                $connector = new Connector();
                                echo $connector->getData();
                            ?>">
                </div>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>
</html>