-- 0. Verificar la versión de SQLite
SELECT sqlite_version();

-- 1. Seleccionar todos los proveedores
SELECT * FROM proveedores;

-- 2. Seleccionar todos los insumos
SELECT * FROM insumos;

-- 3. Seleccionar todos los clientes
SELECT * FROM clientes;

-- 4. Seleccionar todos los pedidos
SELECT * FROM pedidos;

-- 5. Seleccionar proveedores activos
SELECT * FROM proveedores WHERE activo = TRUE;

-- 6. Seleccionar insumos activos
SELECT * FROM insumos WHERE activo = TRUE;

-- 7. Seleccionar clientes activos
SELECT * FROM clientes WHERE activo = TRUE;

-- 8. Seleccionar pedidos activos
SELECT * FROM pedidos WHERE activo = TRUE;

-- 9. Contar la cantidad de insumos en stock por categoría
SELECT categoria, COUNT(*) AS cantidad_insumos
FROM insumos
GROUP BY categoria;

-- 10. Obtener insumos cuyo stock está por debajo del stock mínimo
SELECT * FROM insumos WHERE stock_minimo > 0 AND stock_maximo > stock_minimo;

-- 11. Obtener los nombres de clientes y sus pedidos con el total de la compra
SELECT c.nombre, c.apellido, p.fecha_compra, p.precio_total
FROM clientes c
LEFT JOIN pedidos p ON c.id = p.id_cliente;

-- 12. Obtener insumos comprados en un pedido específico
SELECT i.nombre, i.marca, p.fecha_compra, p.precio_total
FROM insumos i
INNER JOIN pedidos p ON i.id = p.id_insumo
WHERE p.id = 1;

-- 13. Obtener lista de insumos con su respectivo proveedor
SELECT i.nombre AS nombre_insumo, p.nombre_proveedor
FROM insumos i
LEFT JOIN proveedores p ON i.id = p.id_insumo;

-- 14. Listar insumos que son cursos
SELECT * FROM insumos WHERE cursos = TRUE;

-- 15. Contar la cantidad de pedidos realizados por cada cliente
SELECT p.id_cliente, COUNT(p.id) AS cantidad_pedidos
FROM pedidos p
GROUP BY p.id_cliente;

-- 16. Obtener clientes y el insumo que compraron, con la fecha de compra
SELECT c.nombre, c.apellido, i.nombre AS nombre_insumo, p.fecha_compra
FROM clientes c
LEFT JOIN pedidos p ON c.id = p.id_cliente
LEFT JOIN insumos i ON i.id = p.id_insumo;

-- 17. Listar proveedores y el insumo que proveen
SELECT p.razon_social, p.nombre_proveedor, i.nombre AS insumo
FROM proveedores p
LEFT JOIN insumos i ON p.id_insumo = i.id;

-- 18. Seleccionar clientes que han realizado al menos un pedido
SELECT DISTINCT c.nombre, c.apellido
FROM clientes c
INNER JOIN pedidos p ON c.id = p.id_cliente;

-- 19. Obtener clientes que no han realizado ningún pedido
SELECT c.nombre, c.apellido
FROM clientes c
LEFT JOIN pedidos p ON c.id = p.id_cliente
WHERE p.id_cliente IS NULL;

-- 20. Calcular el monto total de todos los pedidos realizados
SELECT SUM(precio_total) AS monto_total_pedidos
FROM pedidos;


select * from clientes;

select * from insumos;

select * from pedidos p join clientes c on p.id_cliente = c.id left join insumos i on p.id_insumo = i.id where p.activo = true; 

select * from v_pedidos;