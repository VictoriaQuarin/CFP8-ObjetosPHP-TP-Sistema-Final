drop table if exists proveedores;

drop table if exists insumos;

drop table if exists clientes;


CREATE TABLE proveedores(
    id integer,
    nombre_tienda varchar(30) not null,
    nombre_proveedor varchar(30) not null,
    id_insumos int null references insumos(id),
    activo boolean default TRUE,
    primary key(id)
);


CREATE TABLE cursos(
    id integer,
    nombre_curso varchar(30) not null,
    alumnos varchar(30) not null,
    id_insumos int null references insumos(id),
    activo boolean default TRUE,
    primary key(id)
);

CREATE TABLE tecnicas(
    id integer,
    nombre_tecnica varchar(30) not null,
    id_alumnos int null references alumnos(id),
    profesor varchar (30) not null,
    activo boolean default TRUE,
    primary key(id)
);

CREATE TABLE alumnos(
    id integer,
    apellido_alumnos varchar(30) not null,
    id
);

CREATE TABLE insumos(
    id integer,
    categoria integer,
    nombre varchar(30) not null,
    cursos varchar(30) not null,
    activo boolean default TRUE,
    primary key(id)
);


CREATE TABLE clientes(
    id integer,
    apellido varchar(30) not null,
    nombre varchar(30) not null,
    id_insumos int null references insumos(id),
    activo boolean default TRUE,
    primary key(id)
);
