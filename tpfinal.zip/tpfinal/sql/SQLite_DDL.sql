-- Active: 1731330431370@@127.0.0.1@3306
drop table if exists proveedores;
drop table if exists insumos;
drop table if exists clientes;
drop table if exists pedidos;


CREATE TABLE proveedores(
    id integer,
    razon_social varchar(30) not null,
    cuit varchar(30) not null,
    nombre_proveedor varchar(30) not null,
    id_insumo integer null references insumos(id),
    domicilio varchar(30) not null,
    telefono integer not null,
    email varchar(30) not null,
    activo boolean default TRUE,
    primary key(id)
);


CREATE TABLE insumos(
    id integer,
    categoria integer,
    marca varchar(30) not null,
    nombre varchar(30) not null,
    cursos boolean default FALSE,
    precio integer null,
    stock_minimo int not null,
    stock_maximo int not null,
    activo boolean default TRUE,
    primary key(id)
);


CREATE TABLE clientes(
    id integer,
    apellido varchar(30) not null,
    nombre varchar(30) not null,
    domicilio varchar(30) not null,
    telefono integer not null,
    mail varchar(30) not null,
    activo boolean default TRUE,
    primary key(id)
);


CREATE TABLE pedidos(
    id integer,
    fecha_compra datetime,
    id_cliente integer null references clientes(id),
    id_insumo integer null references insumos(id),
    precio_total numeric not null,
    activo boolean default TRUE,
    primary key(id)
);