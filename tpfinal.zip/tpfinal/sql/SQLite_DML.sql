-- Inserción de registros en la Tabla Proovedores --
INSERT INTO proveedores (id, razon_social, cuit, nombre_proveedor, id_insumo, domicilio, telefono, email, activo) VALUES
(1, 'Arte y Estilo', '20-12345678-9', 'Juan Pérez', 1, 'Calle Falsa 123', 1123456789, 'contacto@arteyestilo.com', TRUE),
(2, 'Pinceles del Sur', '30-87654321-0', 'Laura Martínez', 2, 'Av. Siempreviva 456', 1198765432, 'info@pincelesdelsur.com', TRUE),
(3, 'Colores Unidos', '27-13524679-8', 'Marcela Gómez', 3, 'Calle Colorida 789', 1145678932, 'marcela@coloresunidos.com', TRUE),
(4, 'Lápices y Más', '21-98765432-1', 'Carlos Fernández', 4, 'Ruta 5 KM 12', 1165432109, 'info@lapicesymas.com', TRUE),
(5, 'Arte Total', '20-11223344-5', 'Ana Castro', 5, 'Av. Central 100', 1122334455, 'contacto@artetotal.com', TRUE),
(6, 'La Paleta Mágica', '23-99887766-2', 'Miguel Ángel', 6, 'Calle Pintura 42', 1133987766, 'miguel@paletamagica.com', TRUE),
(7, 'Tienda Creativa', '30-77665544-3', 'Paula Ruiz', 7, 'Av. de las Artes 33', 1123766544, 'paula@tiendacreativa.com', TRUE),
(8, 'Papel y Pincel', '20-44556677-9', 'Ricardo Vega', 8, 'Calle del Arte 99', 1194455667, 'ricardo@papelypincel.com', TRUE),
(9, 'Expresión y Color', '29-22334455-6', 'Rosa Sánchez', 9, 'Ruta 3 KM 20', 1122233445, 'rosa@expresionycolor.com', TRUE),
(10, 'Arte Urbano', '24-11224488-0', 'Julio Mena', 10, 'Av. Estación 54', 1133124488, 'julio@arteurbano.com', TRUE),
(11, 'Creativos Unidos', '25-33445566-7', 'Andrea García', 11, 'Calle 4 Norte', 1133445566, 'andrea@creativosunidos.com', TRUE),
(12, 'Arte en Papel', '28-44556633-1', 'Luis Torres', 12, 'Calle Papelera 22', 1144556633, 'luis@arteenpapel.com', TRUE),
(13, 'Pinceles y Tintas', '20-99885577-4', 'Eva López', 13, 'Av. de los Pinos 91', 1159985577, 'eva@pincelesytintas.com', TRUE),
(14, 'Fábrica de Arte', '21-88776655-3', 'Pedro Molina', 14, 'Calle Armonía 88', 1178877665, 'pedro@fabricadearte.com', TRUE),
(15, 'Colores y Más', '22-66778855-8', 'Nina Torres', 15, 'Av. Sur 45', 1145566788, 'nina@coloresymas.com', TRUE),
(16, 'Tinta Urbana', '23-99887766-2', 'Lucas Rivero', 16, 'Calle Mayor 21', 1189987766, 'lucas@tintaurbana.com', TRUE),
(17, 'Galería Central', '24-55667788-9', 'Mario Escobar', 17, 'Av. de las Luces 59', 1195566788, 'mario@galeriacentral.com', TRUE),
(18, 'Estudio de Arte', '27-11223344-0', 'Verónica Paz', 18, 'Calle Estudio 14', 1111223344, 'veronica@estudiodearte.com', TRUE),
(19, 'Crearte', '25-22446688-3', 'Sofía Rocha', 19, 'Av. del Sol 23', 1192244668, 'sofia@crearte.com', TRUE),
(20, 'Tienda de Color', '26-77889911-2', 'Enrique Moya', 20, 'Calle Central 57', 1187788991, 'enrique@tiendadecolor.com', TRUE);


-- Inserción de registros en la Tabla Insumos --
INSERT INTO insumos (id, categoria, marca, nombre, cursos, precio, stock_minimo, stock_maximo, activo) VALUES
(1, 1, 'Faber Castell', 'Acrílicos', FALSE, 500, 10, 50, TRUE),
(2, 2, 'Pitt Artist', 'Pincel', FALSE, 250, 5, 40, TRUE),
(3, 1, 'Winsor & Newton', 'Lienzo 30x40', FALSE, 1000, 3, 20, TRUE),
(4, 3, 'Arte Master', 'Curso de Dibujo Básico', TRUE, 2000, 0, 0, TRUE),
(5, 1, 'Arte Pro', 'Carbonilla', FALSE, 300, 5, 25, TRUE),
(6, 4, 'ColorArte', 'Acuarela', FALSE, 600, 10, 60, TRUE),
(7, 2, 'ArteFino', 'Pincel Fino', FALSE, 400, 3, 15, TRUE),
(8, 3, 'Canvas Pro', 'Curso de Pintura', TRUE, 2500, 0, 0, TRUE),
(9, 2, 'BrushLine', 'Pincel Redondo', FALSE, 300, 4, 30, TRUE),
(10, 4, 'Pigmento', 'Óleos', FALSE, 1200, 7, 45, TRUE),
(11, 3, 'ArtCenter', 'Curso de Escultura', TRUE, 3000, 0, 0, TRUE),
(12, 1, 'EcoColor', 'Témpera', FALSE, 350, 8, 30, TRUE),
(13, 5, 'GuíaArte', 'Guía de Técnicas', FALSE, 500, 5, 50, TRUE),
(14, 4, 'Líquidos', 'Barniz Acrílico', FALSE, 450, 6, 25, TRUE),
(15, 5, 'Colorista', 'Papel para Acuarela', FALSE, 250, 5, 25, TRUE),
(16, 3, 'AcademiaArte', 'Curso de Técnicas Mixtas', TRUE, 2200, 0, 0, TRUE),
(17, 1, 'ExpressArte', 'Espátula', FALSE, 150, 2, 20, TRUE),
(18, 4, 'ManoCreadora', 'Caballete', FALSE, 900, 3, 15, TRUE),
(19, 5, 'PincelArte', 'Pincel Angular', FALSE, 275, 4, 20, TRUE),
(20, 2, 'Pluma Artística', 'Rotulador', FALSE, 350, 6, 40, TRUE);


-- Inserción de registros en la Tabla Clientes --
INSERT INTO clientes (id, apellido, nombre, domicilio, telefono, mail, activo) VALUES
(1, 'González', 'Marta', 'Av. Libertador 1500', 1145678901, 'marta.gonzalez@mail.com', TRUE),
(2, 'López', 'Carlos', 'Calle Principal 789', 1198765433, 'carlos.lopez@mail.com', TRUE),
(3, 'Sánchez', 'Clara', 'Ruta 8 KM 23', 1145632198, 'clara.sanchez@mail.com', TRUE),
(4, 'Martínez', 'Esteban', 'Av. Rivadavia 350', 1148975643, 'esteban.martinez@mail.com', TRUE),
(5, 'Rodríguez', 'Ana', 'Calle 12 Norte', 1123546789, 'ana.rodriguez@mail.com', TRUE),
(6, 'Pérez', 'Luis', 'Calle Sur 78', 1156781234, 'luis.perez@mail.com', TRUE),
(7, 'García', 'Laura', 'Ruta 5 KM 45', 1189532167, 'laura.garcia@mail.com', TRUE),
(8, 'Torres', 'Miguel', 'Calle Río 45', 1134567892, 'miguel.torres@mail.com', TRUE),
(9, 'Gómez', 'Beatriz', 'Calle de las Flores 22', 1197531426, 'beatriz.gomez@mail.com', TRUE),
(10, 'Luna', 'Patricia', 'Av. Central 1000', 1171234567, 'patricia.luna@mail.com', TRUE),
(11, 'Morales', 'Hugo', 'Ruta Nacional 7', 1127643812, 'hugo.morales@mail.com', TRUE),
(12, 'Rivera', 'Silvia', 'Calle Norte 12', 1182937465, 'silvia.rivera@mail.com', TRUE),
(13, 'Silva', 'Fernando', 'Av. Oeste 45', 1195678432, 'fernando.silva@mail.com', TRUE),
(14, 'Giménez', 'Elena', 'Calle Amanecer 66', 1134671238, 'elena.gimenez@mail.com', TRUE),
(15, 'Molina', 'Juliana', 'Ruta 6 KM 34', 1157693245, 'juliana.molina@mail.com', TRUE),
(16, 'Fernández', 'Ricardo', 'Calle Nueva 78', 1164321987, 'ricardo.fernandez@mail.com', TRUE),
(17, 'Ruiz', 'Gloria', 'Av. Principal 250', 1145674312, 'gloria.ruiz@mail.com', TRUE),
(18, 'Soto', 'Jorge', 'Calle 15 Este', 1197654345, 'jorge.soto@mail.com', TRUE),
(19, 'Aguilar', 'Daniela', 'Callejón del Sol 9', 1187654319, 'daniela.aguilar@mail.com', TRUE),
(20, 'Guzmán', 'Raúl', 'Ruta Provincial 4', 1176541238, 'raul.guzman@mail.com', TRUE);


-- Inserción de registros en la Tabla Pedidos --
INSERT INTO pedidos (id, fecha_compra, id_cliente, id_insumo, precio_total, activo) VALUES
(1, '2024-11-01 09:30:00', 1, 1, 500, TRUE),
(2, '2024-11-02 10:15:00', 2, 2, 250, TRUE),
(3, '2024-11-03 11:45:00', 3, 3, 1000, TRUE),
(4, '2024-11-04 08:20:00', 4, 4, 2000, TRUE),
(5, '2024-11-05 13:00:00', 5, 5, 300, TRUE),
(6, '2024-11-06 15:40:00', 6, 6, 600, TRUE),
(7, '2024-11-07 12:10:00', 7, 7, 400, TRUE),
(8, '2024-11-08 17:00:00', 8, 8, 2500, TRUE),
(9, '2024-11-09 14:30:00', 9, 9, 300, TRUE),
(10, '2024-11-10 16:20:00', 10, 10, 1200, TRUE),
(11, '2024-11-11 10:10:00', 11, 11, 3000, TRUE),
(12, '2024-11-12 18:45:00', 12, 12, 350, TRUE),
(13, '2024-11-13 09:00:00', 13, 13, 500, TRUE),
(14, '2024-11-14 20:00:00', 14, 14, 450, TRUE),
(15, '2024-11-15 11:30:00', 15, 15, 250, TRUE),
(16, '2024-11-16 14:45:00', 16, 16, 2200, TRUE),
(17, '2024-11-17 16:00:00', 17, 17, 150, TRUE),
(18, '2024-11-18 19:20:00', 18, 18, 900, TRUE),
(19, '2024-11-19 21:10:00', 19, 19, 275, TRUE),
(20, '2024-11-20 09:50:00', 20, 20, 350, TRUE);