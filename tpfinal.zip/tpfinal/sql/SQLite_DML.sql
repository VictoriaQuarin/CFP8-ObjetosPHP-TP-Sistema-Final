-- Inserción de registros en la Tabla Proovedores --
INSERT INTO proveedores(id, razon_social, cuit, nombre_proveedor, id_insumo, domicilio, telefono, email, activo) VALUES
(1, 'Plumeria', 44-3242325-34,'Graciela Viviana Quarin', 1, 'Dean Funes 326', 324234, 'gracielaquarin@gmail.com', TRUE),
(2, 'El Rey del Fibrofácil', 41-3534634-89, 'Claudio Fernández', 2, 'San Martín 1009', 12351, 'claudiof@hotmail.com', TRUE),
(3, 'Carumel', 22-99812-78, 'Ariana Gómez', 3, 'Gorriti 900', 12303, 'a_gomez@hotmail.com', TRUE),
(4, 'Luz de Luna', 45-234324-53, 'Leonardo Bressan', 4, 'Costa Rica 32', 'bressan01@gmail.com', 9999, TRUE),
(5, 'Expo Resinas', 23-12132-24, 'Gloria Juárez', 5, 'Corrientes 12', 'gloriaj_resinas@hotmail.com', 122, TRUE),

-- Inserción de registros en la Tabla Insumos --
INSERT INTO insumos(id, categoria, marca, nombre, cursos, precio, stock_minimo, stock_maximo, activo) VALUES



-- Inserción de registros en la Tabla Clientes --
INSERT INTO clientes(id, apellido, nombre, domicilio, telefono, mail, activo) VALUES



-- Inserción de registros en la Tabla Pedidos --
INSERT INTO pedidos(id, fecha_compra, id_cliente, id_insumo, precio_total, activo) VALUES