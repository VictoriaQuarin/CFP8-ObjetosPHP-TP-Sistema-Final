<?php ini_set("display_errors", "1");?>
<?php

$myPDO = new PDO('sqlite:../../data/artistica.db');
$result = $myPDO->query('select sqlite_version()');

echo $result->rowCount().'<br>';
foreach($result as $row){
    print $row[0] . "\n";
}