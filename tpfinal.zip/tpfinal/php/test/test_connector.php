<?php ini_set("display_errors", "1");?>
<?php
include_once '../connectors/connector.php';

//http://localhost/objetos/tpfinal/php/test/test_connector.php

echo '<h2>-- Trabajo Práctico Final --</h2><br>';



/*  -- DESCRIPCIÓN DEL ESTADO DE LA SALIDA PARA CADA TEST --

    1) GETCONNECTION() --> Salida correcta.

    2) INSERT --> El nuevo insumo se incluye en la tabla, en la base de datos.

    3) DELETE --> NO se produce la eliminación.

    4) UPDATE --> Se produce el cambio de nombre de forma correcta, en la base de datos. 

    5) GET() - APELLIDO %M --> NO se ejecuta correctamente, NO hay salida.

    6) GETALL() --> Salida correcta.

*/



// TEST DE CONEXIÓN
echo '-- Inicio de Test Connector --<br>';
$connector=new Connector();
$sql="select sqlite_version()";
try{
    $registros = $connector->getConnection()->query($sql);
    echo 'La conexión se realizó de manera exitosa.<br>';
    foreach($registros as $row){
        echo 'La conexión se realizó a la versión: '.$row[0].'<br>';
    }
}catch(Exception $e){
    echo 'Se produjo un error de conexión.<br>';
    echo $e. '<br>';
}
echo '-- Fin de Test Connector --<br><br><br>';


// TEST DE INSERCIÓN EN 'INSUMOS'
$connector->insert(
                    "insumos",
                    "categoria, marca, nombre, cursos, precio, stock_minimo, stock_maximo",
                    values: "21, 'ExpressArte', 'Lápiz B1', FALSE, 200, 5, 50"
                );


// TEST DELETE EN 'INSUMOS'
$connector->delete("insumos", "id=10");


// TEST UPDATE EN 'INSUMOS'
$connector->update("insumos", "nombre='Pintura a la tiza'", "id=17");


// TEST DE FILTRADO POR APELLIDO
echo '-- Inicio Test .get() --<br>';
$registros = $connector->get("clientes", "apellido like '%m'");
foreach($registros as $row){
    echo $row['id'].", ".$row['apellido'].", ".$row['nombre'].", ".
    $row['domicilio'].", ".$row['telefono'].", ".$row['mail']."<br>";
}
echo '-- Fin Test .get() --<br><br><br>';


// TEST GETALL()
echo '-- Inicio Test .getAll() --<br>';
$registros = $connector->getAll("proveedores");
foreach($registros as $row){
    echo $row['id'].", ".$row['razon_social'].", ".$row['cuit'].", ".$row['nombre_proveedor'].", ".
    $row['id_insumo'].", ".$row['domicilio'].", ".$row['telefono'].", ".$row['email']."<br>";
}
echo '-- Fin Test .get() --<br>';


?>