<?php ini_set("display_errors", "1");?>
<?php
include_once '../connectors/connector.php';

//http://localhost/objetos/tpfinal/php/test/test_connector.php

echo '<h2>-- Trabajo Práctico Final --</h2><br>';


// TEST DE CONEXIÓN
echo '-- Inicio de Test Connector --<br>';
$connector=new Connector();
$sql="select sqlite_version()";
try{
    $registros = $connector->getConnection()->query($sql);
    echo 'La conexión se realizó de manera exitosa.<br>';
    foreach($registros as $row){
        echo 'La conexión se realizó a la versión: '.$row[0].'<br>';
    }
}catch(Exception $e){
    echo 'Se produjo un error de conexión.<br>';
    echo $e. '<br>';
}
echo '-- Fin de Test Connector --<br><br><br>';


// TEST DE INSERCIÓN EN 'INSUMOS'
$connector->insert(
                    "insumos",
                    "categoria, marca, nombre, cursos, precio, stock_minimo, stock_maximo",
                    values: "21, 'ExpressArte', 'Lápiz B1', FALSE, 200, 5, 50"
                );


// TEST DELETE EN 'INSUMOS'
$connector->delete("insumos", "id=10");


// TEST UPDATE EN 'INSUMOS'
$connector->update("insumos", "nombre='Pintura a la tiza'", "id=17");


// TEST DE FILTRADO POR APELLIDO
echo '-- Inicio Test .get() --<br>';
$registros = $connector->get("insumos", "marca like '%Canvas Pro'");
foreach($registros as $row){
    echo $row['id'].", ".$row['categoria'].", ".$row['marca'].", ".$row['nombre'].", ".
    $row['cursos'].", ".$row['precio'].", ".$row['stock_minimo'].", ".$row['stock_maximo']."<br>";
}
echo '-- Fin Test .get() --<br><br><br>';


// TEST GETALL()
echo '-- Inicio Test .getAll() --<br>';
$registros = $connector->getAll("insumos");
foreach($registros as $row){
    echo $row['id'].", ".$row['categoria'].", ".$row['marca'].", ".$row['nombre'].", ".
    $row['cursos'].", ".$row['precio'].", ".$row['stock_minimo'].", ".$row['stock_maximo']."<br>";
}
echo '-- Fin Test .get() --<br>';


?>