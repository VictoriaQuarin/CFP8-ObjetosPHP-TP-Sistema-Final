<?php ini_set("display_errors", "1"); ?>
<?php

include_once 'php/connectors/connector.php';

if (
    isset($_REQUEST['categoria']) && $_REQUEST['categoria'] != '' &&
    isset($_REQUEST['marca']) && $_REQUEST['marca'] != '' &&
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['precio']) && $_REQUEST['precio'] != '' &&
    isset($_REQUEST['stock_minimo']) && $_REQUEST['stock_minimo'] != '' &&
    isset($_REQUEST['stock_maximo']) && $_REQUEST['stock_maximo'] != ''
) {
    $categoria = $_REQUEST['categoria'];
    $marca = $_REQUEST['marca'];
    $nombre = $_REQUEST['nombre'];
    $cursos = isset($_REQUEST['cursos']) ? 1:0;
    $precio = $_REQUEST['precio'];
    $stock_minimo = $_REQUEST['stock_minimo'];
    $stock_maximo = $_REQUEST['stock_maximo'];

    $tabla = "insumos";
    $campos = "categoria, marca, nombre, cursos, precio, stock_minimo, stock_maximo";
    $values = "'" . $categoria ."', '" . $marca ."', '" . $nombre ."', " . $cursos .", '" . $precio ."', '" . $stock_minimo ."', '" .$stock_maximo ."'";
    $connector=new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingresó correctamente un nuevo insumo';
} else {
    echo 'Ingresar un nuevo insumo';
}
?>