<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if(
    isset($_REQUEST['razon_social']) && $_REQUEST['razon_social'] != '' &&
    isset($_REQUEST['cuit']) && $_REQUEST['cuit'] != '' &&
    isset($_REQUEST['nombre_proveedor']) && $_REQUEST['nombre_proveedor'] != '' &&
    isset($_REQUEST['domicilio']) && $_REQUEST['domicilio'] != '' &&
    isset($_REQUEST['telefono']) && $_REQUEST['telefono'] != '' &&
    isset($_REQUEST['email']) && $_REQUEST['email'] != ''
) {
    $razon_social = $_REQUEST['razon_social'];
    $cuit = $_REQUEST['cuit'];
    $nombre_proveedor = $_REQUEST['nombre_proveedor'];
    $id_insumo = $_REQUEST['id_insumo'];
    $domicilio = $_REQUEST['domicilio'];
    $telefono = $_REQUEST['telefono'];
    $email = $_REQUEST['email'];

    $tabla = "proveedores";
    $campos = "razon_social, cuit, nombre_proveedor, id_insumo, domicilio, telefono, email";
    $values = "'" . $razon_social ."', '" . $cuit ."', '" . $nombre_proveedor ."', '" . $id_insumo ."', '" . $domicilio ."', '" . $telefono ."', '" .$email ."'";
    $connector=new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingresó correctamente un nuevo proveedor';
} else {
    echo 'Ingresar un nuevo proveedor';
}
?>