<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['fecha_compra']) && $_REQUEST['fecha_compra'] != '' &&
    isset($_REQUEST['precio_total']) && $_REQUEST['precio_total'] != ''
) {
    $fecha_compra = $_REQUEST['fecha_compra'];
    $id_cliente = $_REQUEST['id_cliente'];
    $id_insumo = $_REQUEST['id_insumo'];
    $precio_total = $_REQUEST['precio_total'];

    $tabla = "pedidos";
    $campos = "fecha_compra, id_cliente, id_insumo, precio_total";
    $values = "'" . $fecha_compra ."', '" . $id_cliente ."', '" . $id_insumo ."', '" . $precio_total ."'";
    $connector=new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingresó correctamente un nuevo pedido';
} else {
    echo 'Ingresar un nuevo pedido';
}
?>