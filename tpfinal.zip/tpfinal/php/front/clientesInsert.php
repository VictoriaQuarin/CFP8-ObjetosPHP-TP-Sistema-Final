<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['apellido']) && $_REQUEST['apellido'] != '' &&
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['domicilio']) && $_REQUEST['domicilio'] != '' &&
    isset($_REQUEST['telefono']) && $_REQUEST['telefono'] != '' &&
    isset($_REQUEST['mail']) && $_REQUEST['mail'] != ''
) {
    $apellido = $_REQUEST['apellido'];
    $nombre = $_REQUEST['nombre'];
    $domicilio = $_REQUEST['domicilio'];
    $telefono = $_REQUEST['telefono'];
    $mail = $_REQUEST['mail'];

    $tabla = "clientes";
    $campos = "apellido, nombre, domicilio, telefono, mail";
    $values = "'" . $apellido ."', '" . $nombre ."', '" . $domicilio ."', '" . $telefono ."', '" . $mail ."'";
    $connector=new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingresó correctamente un nuevo cliente';
} else {
    echo 'Ingresar un nuevo cliente';
}
?>