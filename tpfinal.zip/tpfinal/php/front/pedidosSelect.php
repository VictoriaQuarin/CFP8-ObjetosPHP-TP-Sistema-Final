<?php
include_once "php/connectors/connector.php";

$connector=new Connector();
$registros=$connector->getAll("pedidos");

foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] ."'>" .
            $registro['id'].', '.$registro['fecha_compra'].', '.$registro['id_cliente']
            .', '.$registro['id_insumo'].', '.$registro['precio_total']
        ."</option>";
}
?>