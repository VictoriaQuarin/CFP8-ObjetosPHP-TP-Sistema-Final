<?php
include_once "php/connectors/connector.php";

$connector=new Connector();
$registros=$connector->getAll("insumos");

foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] ."'>" .
            $registro['id'].', '.$registro['categoria'].', '.$registro['marca']
            .', '.$registro['nombre'].', '.$registro['cursos'].', '.$registro['precio']
            .', '.$registro['stock_minimo'].', '.$registro['stock_maximo']
        ."</option>";
}
?>