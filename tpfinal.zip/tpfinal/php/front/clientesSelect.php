<?php
include_once "php/connectors/connector.php";

$connector=new Connector();
$registros=$connector->getAll("clientes");

foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] ."'>" .
            $registro['id'].', '.$registro['apellido'].', '.$registro['nombre']
            .', '.$registro['domicilio'].', '.$registro['telefono'].', '.$registro['mail']
        ."</option>";
}
?>