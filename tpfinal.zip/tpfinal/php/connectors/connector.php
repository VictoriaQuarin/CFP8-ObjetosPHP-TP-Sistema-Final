<?php

class Connector{
    
    /*
    El DIR del código siguiente; hace referencia a la ruta:
        "c:\\xampp\\htdocs\\objetos\\tpfinal\\php\\connectors"

    public function getConnection() {
        $driver='sqlite';
        $file='../../data/artistica.db';
        $file=__DIR__.'/data/artistica.db';
        echo $file;
        return new PDO("$driver:$file");
    }

    Al considerar esa ruta (que no es la correcta), la salida al ejecutar test_connector; devuelve error.
    */


    /*
    -- Manual de PHP --
    Fuente: https://www.php.net/manual/es/reserved.variables.server.php
    Variable Predefinida: $_SERVER
    
    $_SERVER es un array que contiene información, tales como cabeceras, rutas y ubicaciones de script. 
    Las entradas de este array son creadas por el servidor web.

    'DOCUMENT_ROOT'
    El directorio raíz de documentos del servidor en el cual se está ejecutando el script actual,
    según está definida en el archivo de configuración del servidor.
    */


    public function getConnection() {
        $driver = 'sqlite';
        $file = $_SERVER['DOCUMENT_ROOT'] . '/objetos/tpfinal/data/artistica.db';
        return new PDO("$driver:$file");
    }


    public function getData() {
        return "SQLite 3";
    }


    public function insert ($tabla, $campos, $values) {
        $sql="insert into $tabla ($campos) values ($values)";
        return $this->getConnection()->exec($sql);
    }


    public function delete ($tabla, $filtro) {
        $sql="update $tabla set activo=false where $filtro";
        return $this->getConnection()->exec($sql);
    }


    public function update ($tabla, $set, $filtro) {
        $sql="update $tabla set $set where $filtro";
        return $this->getConnection()->exec($sql);
    }


    public function get($tabla, $filtro) {
        $sql="select * from $tabla where $filtro and activo=true";
        return $this->getConnection()->query($sql);
    }


    public function getAll($tabla) {
        return $this->get($tabla, "1=1");
    }

}
?>