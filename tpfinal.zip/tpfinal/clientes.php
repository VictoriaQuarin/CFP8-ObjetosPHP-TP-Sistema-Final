<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artística Plumeria</title>
    <link rel="icon" href="images/logo.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="css/style.css?v=1.1" rel="stylesheet">
</head>

<body>
    <div class="container-lg">

        <!-- Menú de Navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h2>Lista de Clientes</h2>

        <!-- Formulario de Clientes -->
        <form class="bg-secondary-subtle text-start p-2">


            <!-- Apellido -->
            <div class="mb-3 row">
                <label for="apellido" class="col-sm-2 col-form-label text-secondary">Apellido</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="apellido"
                        name="apellido" value="">
                </div>
            </div>


            <!-- Nombre -->
            <div class="mb-3 row">
                <label for="nombre" class="col-sm-2 col-form-label text-secondary">Nombre</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="nombre"
                        name="nombre" value="">
                </div>
            </div>


            <!-- Domicilio -->
            <div class="mb-3 row">
                <label for="domicilio" class="col-sm-2 col-form-label text-secondary">Domicilio</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="domicilio"
                        name="domicilio" value="">
                </div>
            </div>

        
            <!-- Teléfono -->
            <div class="mb-3 row">
                <label for="telefono" class="col-sm-2 col-form-label text-secondary">Teléfono</label>
                <div class="col-sm-5">
                    <input type="number" class="form-control text-dark" id="telefono"
                        name="telefono" value="">
                </div>
            </div>


            <!-- Mail -->
            <div class="mb-3 row">
                <label for="telefono" class="col-sm-2 col-form-label text-secondary">Mail</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control text-dark" id="mail"
                        name="mail" value="">
                </div>
            </div>


            <!-- Botones -->
            <div class="mb-3 row">
                <button type="submit" class="btn btn-outline-success btn-sm col-sm-1 m-1">Guardar</button>
                <button type="reset" class="btn btn-outline-danger btn-sm col-sm-1 m-1">Borrar</button>
            </div>


            <!-- Información -->
            <div class="mb-3 row">
                <label for="informacion" class="col-sm-2 col-form-label text-secondary">Información</label>
                <div class="col-sm-5">
                    <div class="form-control text-dark" id="info">
                        <?php include_once "php/front/clientesInsert.php"; ?>
                    </div>
                </div>
            </div>
        </form>


            <!-- Lista de Clientes -->
            <table class="table table-success table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">ID del Cliente</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Domicilio</th>
                        <th scope="col">Teléfono</th>
                        <th scope="col">E-Mail</th>
                        <th scope="col">Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/clientesTable.php"; ?>
                </tbody>
            </table>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>
</html>