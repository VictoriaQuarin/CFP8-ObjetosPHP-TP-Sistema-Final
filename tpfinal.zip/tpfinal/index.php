<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Artística Plumeria</title>
  <link rel="icon" href="images/logo.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="css/style.css?v=1.1" rel="stylesheet">
</head>

<body>
  <div container-lg>

    <!-- Menú de Navegación -->
    <?php include_once "menu.php"; ?>

    <!-- Banner -->
    <h1>Artística Plumeria</h1>


    <div class="container mt-5">
      <div class="row justify-content-between">
        
        <!-- Componente de Bootstrap - 'Tarjeta' -->
        <!-- Fuente: https://getbootstrap.esdocu.com/docs/5.3/components/card/ -->
      
        <!-- Tarjeta 1 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica1.jpg" class="card-img-top" alt="Imagen artística 1"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Contamos con una amplia variedad de insumos para confeccionar sus piezas artísticas.</p>
            </div>
          </div>
        </div>

        <!-- Tarjeta 2 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica2.jpg" class="card-img-top" alt="Imagen artística 2"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Cada cliente es atendido de forma personalizada, atendiendo a todas sus consultas.</p>
            </div>
          </div>
        </div>

        <!-- Tarjeta 3 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica3.jpg" class="card-img-top" alt="Imagen artística 3"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Formamos parte de la comunidad creativa desde hace casi 60 años.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>

</body>
</html>