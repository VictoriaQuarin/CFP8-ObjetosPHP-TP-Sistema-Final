<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Artística Plumeria</title>
  <link rel="icon" href="images/logo.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="css/style.css?v=1.1" rel="stylesheet">
</head>

<body>
  <div class="container-lg">

    <!-- Menú de Navegación -->
    <?php include_once "menu.php"; ?>

    <!-- Banner -->
    <h1>Artística Plumeria</h1>


    <div class="container mt-5">
      <div class="row justify-content-between">

      <!-- Componente de Bootstrap - 'Carrusel' -->
      <!-- Fuente: https://getbootstrap.esdocu.com/docs/5.3/components/carousel/ -->

        <div id="carouselExampleCaptions" class="carousel slide mb-5" data-bs-ride="carousel">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="images/artistica4.jpg" class="d-block w-100" alt="artistica4">
            <div class="carousel-caption d-none d-md-block">
            <h5>Pinceles</h5>
            <p>Amplia variedad de pinceles, de acuerdo a sus necesidades.</p>
        </div>
      </div>
        <div class="carousel-item">
          <img src="images/artistica5.jpg" class="d-block w-100" alt="artistica5">
          <div class="carousel-caption d-none d-md-block">
            <h5>Pinturas Acrílicas y Óleos</h5>
            <p>Extenso catálogo de colores y productos.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="images/artistica6.jpg" class="d-block w-100" alt="artistica6">
          <div class="carousel-caption d-none d-md-block">
            <h5>Cursos</h5>
            <p>Ofrecemos talleres y seminarios para todas las edades.</p>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>


      <!-- Componente de Bootstrap - 'Tarjeta' -->
      <!-- Fuente: https://getbootstrap.esdocu.com/docs/5.3/components/card/ -->
      
        <!-- Tarjeta 1 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica1.jpg" class="card-img-top" alt="Imagen artística 1"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Contamos con una amplia variedad de insumos para confeccionar sus piezas artísticas.</p>
            </div>
          </div>
        </div>

        <!-- Tarjeta 2 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica2.jpg" class="card-img-top" alt="Imagen artística 2"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Cada cliente es atendido de forma personalizada, atendiendo a todas sus consultas.</p>
            </div>
          </div>
        </div>

        <!-- Tarjeta 3 -->
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="images/artistica3.jpg" class="card-img-top" alt="Imagen artística 3"
              style="object-fit: cover; height: 200px;">
            <div class="card-body">
              <p class="card-text">Formamos parte de la comunidad creativa desde hace casi 60 años.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="js/main.js"></script>
</body>
</html>