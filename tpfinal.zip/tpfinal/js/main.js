function confirmarBorrar(){
    return confirm("¿Desea borrar el registro?")
}